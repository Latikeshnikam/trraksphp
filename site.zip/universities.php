<?php

include("header.php");
 ini_set('display_errors', '0');
 


if (isset($USER_LOGGED_IN)) {

require "configure.php";
$country=$Stream=$Entrance_Exam=$EntranceScore=$Verbal_Exam=$Verb_Score="";

$countryErr=$streamErr=$Entrance_ExamErr=$EntranceScoreErr=$Verbal_ExamErr=$VerbalScoreErr="";

if (isset($_GET['EVALUATE'])) 
{    
    $_SESSION['country']= $_GET["Country"];
    $_SESSION['stream']=$_GET["Stream"];
    $_SESSION['EntExam']= $_GET["Entrance_Exam"];
    $_SESSION['EntExamScr']= $_GET["EntranceScore"];
    $_SESSION['VerExam']=$_GET["Verbal_Exam"];
    $_SESSION['VerExamScr']= $_GET["VerbalScore"];  

}
 ini_set('display_errors', '0');
?>

<div class="container"> 
<div class="row p-2">
  <div class="col-md-7" id="shortlisted-university">
    <div class="md-12 mb-2">          
        <button type="button" id="ModalForm" class="btn col-md-12 btn-lg animated infinite pulse" data-toggle="modal" data-target="#admissionform" data-whatever="@mdo" style="background-color: #00193f; color: white;">Proceed with Admission <i class="far fa-hand-point-left"></i></button>        
    </div>
<!-- modificatio search div -->
    <!-- div of ajax and json generated universities shortlisted are here.... -->
  </div>
  <div class="col-md-5">
    <div class="card col-md-12 col-sm-12 mb-2 ">
        <img src="img/nomadcredits.png" alt="Nomad Credits">
    </div>
    <form class="needs-validation" id="StudentRecord" method="POST" novalidate>
    <div class="card">
            <div class="card-body">
                    <h2 class="text-center"><i class="fas fa-university"></i>Fill out the fields to explore more about universities</h2>
                    <h5 class="card-title"><i class="fas fa-graduation-cap"></i> Current Education</h5>
                    <p class="card-text"></p>
              <div class="form-row">
                <div class="col-md-6 mb-3 col-sm-6">
                  <label for="CurrentDegree">Current Degree</label>
                  
                  <select id="CurrentDegree" name="CurrentDegree" class="form-control">
                    <option value="" >Choose...</option>
                    <option value="BE">BE</option>
                    <option value="B.Sc">B.Sc</option>
                    <option value="B.Tech">B.Tech</option>
                    <option value="MBA">MBA</option>
                    <option value="MCA">MCA</option>
                    <option value="ME">ME</option>
                    <option value="M.Sc">M.Sc</option>
                    <option value="M.Tech">M.Tech</option>
                    <option value="Other UG/PG">Other UG/PG</option>
                  </select>
                  
                </div>
                <div class="col-md-6 mb-3 col-sm-6">
                  <label for="CurrentMajor">Current Major</label>
                  <select id="CurrentMajor" name="CurrentMajor" class="form-control">
                    <option value="">Choose...</option>
                    <option value="Aeronotical">Aeronotical</option>
                    <option value="Agriculture">Agriculture</option>
                    <option value="AIE">AIE</option>
                    <option value="Automobile">Automobile</option>
                    <option value="BioChemical">BioChemical</option>
                    <option value="BioInformatics">BioInformatics</option>
                    <option value="BioMedical">BioMedical</option>
                    <option value="BioTechnology">BioTechnology</option>
                    <option value="Chemical">Chemical</option>
                    <option value="Civil">Civil</option>
                    <option value="CSE">CSE</option>
                    <option value="ECE">ECE</option>
                    <option value="EEE">EEE</option>
                    <option value="EIE">EIE</option>
                    <option value="EnergyTechnology">EnergyTechnology</option>
                    <option value="Environmental">Environmental</option>
                    <option value="FireSafety">FireSafety</option>
                    <option value="FoodTechology">FoodTechology</option>
                    <option value="Genetic">Genetic</option>
                    <option value="GeoInformatics">GeoInformatics</option>
                    <option value="GeoScience">GeoScience</option>
                    <option value="IndustrailEngg">IndustrailEngg</option>
                    <option value="IndustrialProduction">IndustrialProduction</option>
                    <option value="InstrumentaionControl">InstrumentaionControl</option>
                    <option value="IT">IT</option>
                    <option value="Leather">Leather</option>
                    <option value="ManMadFiber">ManMadFiber</option>
                    <option value="Manufacturing">Manufacturing</option>
                    <option value="Marine">Marine</option>
                    <option value="MaterialScience">MaterialScience</option>
                    <option value="Mechanical">Mechanical</option>
                    <option value="Mechatronics">Mechatronics</option>
                    <option value="Metallurgical">Metallurgical</option>
                    <option value="Mining">Mining</option>
                    <option value="OceanEngineering">OceanEngineering</option>
                    <option value="ProductionEngineering">ProductionEngineering</option>
                    <option value="ProductionIndustrial">ProductionIndustrial</option>
                    <option value="Textile">Textile</option>
                    <option value="Other">Other</option>	
                  </select>
                  
                  </div>
                
                <div class="col-md-12 mb-3">
                  <label for="AttendedUniversity">Attended College/University</label>
                  <select id="AttendedUniversity" name="AttendedUniversity" class="form-control">
                    <option value="" >Select university</option>
                    <option value="IIT-Madras">IIT Madras </option>
                    <option value="IIT-Bombay">IIT Bombay </option>
                    <option value="IIT-Kharagpur">IIT Kharagpur </option>
                    <option value="IIT-Delhi">IIT Delhi </option>
                    <option value="IIT-Kanpur">IIT Kanpur </option>
                    <option value="IIT-Roorkee">IIT Roorkee </option>
                    <option value="IIT-Guwahati">IIT Guwahati </option>
                    <option value="Anna_University_Chennai">Anna University, Chennai </option>
                    <option value="Jadavpur University">Jadavpur University </option>
                    <option value="IIT-Hyderabad">IIT Hyderabad </option>
                    <option value="NIT-Tiruchirappalli">NIT Tiruchirappalli </option>
                    <option value="NIT-Rourkela">NIT Rourkela </option>
                    <option value="VIT-Vellore">VIT, Vellore </option>
                    <option value="Institute of Chemical Tech., Mumbai">Institute of Chemical Tech., Mumbai </option>
                    <option value="IIT-Indore">IIT Indore </option>
                    <option value="BITS Pilani">BITS Pilani </option>
                    <option value="Indian Institute of Engg., Sci. and Tech., Shibpur">Indian Institute of Engg., Sci. and Tech., Shibpur </option>
                    <option value="IIT-Bhubaneswar">IIT Bhubaneswar </option>
                    <option value="IIT-Patna">IIT Patna </option>
                    <option value="Jamia Millia Islamia">Jamia Millia Islamia </option>
                    <option value="IIT-Ropar">IIT Ropar </option>
                    <option value="NIT-Surathkal">NIT Surathkal </option>
                    <option value="ISM Dhanbad">ISM Dhanbad </option>
                    <option value="College of Engineering, Pune">College of Engineering, Pune </option>
                    <option value="Shanmugha Arts,Science,Tech & Research Academy, Thanjavur">Shanmugha Arts,Sci.,Tech. & Research Academy, Thanjavur </option>
                    <option value="Thapar University, Patiala">Thapar University, Patiala </option>
                    <option value="Sri Sivasubramaniya Nadar College of Engg, Kalavakkam">Sri Sivasubramaniya Nadar College of Engg, Kalavakkam</option>
                    <option value="Indian Institute of Space,Sci. & Tech.,Thiruvananthapuram">Indian Institute of Space,Sci. & Tech.,Thiruvananthapuram </option>
                    <option value="IIT-Mandi">IIT Mandi </option>
                    <option value="IIT-Gandhinagar">IIT Gandhinagar </option>
                    <option value="IIT-Varanasi">IIT Varanasi </option>
                    <option value="Birla Institute of Tech., Ranchi">Birla Institute of Tech., Ranchi </option>
                    <option value="PSG College of Techn., Coimbatore">PSG College of Techn., Coimbatore </option>
                    <option value="NIT Warangal">NIT Warangal </option>
                    <option value="SRM Institute of Sci & Tech., Chennai">SRM Institute of Sci & Tech., Chennai </option>
                    <option value="National Institute of Industrial Engg, Mumbai">National Institute of Industrial Engg, Mumbai </option>
                    <option value="Thiagarajar College of Engg, Madurai">Thiagarajar College of Engg, Madurai </option>
                    <option value="Pondicherry Engineering College, Puducherry">Pondicherry Engineering College, Puducherry </option>
                    <option value=">Delhi Technological University, New Delhi">Delhi Technological University, New Delhi </option>
                    <option value="Zakir Husain College of Engg & Tech., Aligarh">Zakir Husain College of Engg & Tech., Aligarh </option>
                    <option value="Motilal Nehru National Institute of Tech., Allahabad">Motilal Nehru National Institute of Tech., Allahabad </option>
                    <option value="Visvesvaraya National Institute of Tech., Nagpur">Visvesvaraya National Institute of Tech., Nagpur </option>
                    <option value="Manipal Institute of Tech., Manipal">Manipal Institute of Tech., Manipal </option>
                    <option value="NIT-Calicut ">NIT Calicut </option>
                    <option value="MS Ramaiah Institute of Tech., Bengaluru">MS Ramaiah Institute of Tech., Bengaluru </option>
                    <option value="AMITY University, Gautam Budh Nagar">AMITY University, Gautam Budh Nagar </option>
                    <option value="Kalinga Institute of Industrial Tech., Bhubneswar">Kalinga Institute of Industrial Tech., Bhubneswar </option>
                    <option value="Sri Venkateswara University, Tirupati">Sri Venkateswara University, Tirupati </option>
                    <option value="RV College of Engineering, Bengaluru">RV College of Engineering, Bengaluru </option>
                    <option value="Sardar Vallabhbhai Patel National Institute of Tech., Surat">Sardar Vallabhbhai Patel National Institute of Tech., Surat </option>
                    <option value="Coimbatore Institute of Tech., Coimbatore">Coimbatore Institute of Tech., Coimbatore </option>
                    <option value="BMS College of Engg, Bengaluru">BMS College of Engg, Bengaluru </option>
                    <option value="NIT-Silchar">NIT Silchar </option>
                    <option value="Jaypee Institute of IT, Noida">Jaypee Institute of IT, Noida </option>
                    <option value="NIT Durgapur">NIT Durgapur </option>
                    <option value="Indraprastha Institute of IT, New Delhi">Indraprastha Institute of IT, New Delhi </option>
                    <option value="Kongu Engg College, Perundurai">Kongu Engg College, Perundurai </option>
                    <option value="Vel Tech Rangarajan Dr S. R. and D Institute of Sci.&Tech., Chennai">Vel Tech Rangarajan Dr S. R. and D Institute of Sci.&Tech., Chennai </option>
                    <option value="NIT-Hamirpur">NIT Hamirpur </option>
                    <option value="NIT-Kurukshetra">NIT Kurukshetra </option>
                    <option value="Maulana Azad National Institute of Technology, Bhopal">Maulana Azad National Institute of Technology, Bhopal </option>
                    <option value="Karunya Institute of Technology amd Sciences, Coimbatore">Karunya Institute of Technology amd Sciences, Coimbatore </option>
                    <option value="Jawaharlal Nehru Technological University, Hyderabad">Jawaharlal Nehru Technological University, Hyderabad </option>
                    <option value="Shri Ramdeobaba College of Engineering and Management, Nagpur">Shri Ramdeobaba College of Engineering and Management, Nagpur </option>
                    <option value="IIT-Jodhpur ">IIT Jodhpur </option>
                    <option value="Bharati Vidyapeeth Deemed University College of Engineering, Pune">Bharati Vidyapeeth Deemed University College of Engineering, Pune </option>
                    <option value="GH Raisoni College of Engineering, Nagpur">GH Raisoni College of Engineering, Nagpur </option>
                    <option value="KL College of Engineering, Vaddeswaram">KL College of Engineering, Vaddeswaram </option>
                    <option value="P. D. P. M. Indian Institute of IT, Design & Manufacturing, Jabalpur">P. D. P. M. Indian Institute of IT, Design & Manufacturing, Jabalpur </option>
                    <option value="Malaviya National Institute of Technology, Jaipur">Malaviya National Institute of Technology, Jaipur </option>
                    <option value="D. Ambani Institute of Information & CT, Gandhinaga">D. Ambani Institute of Information & CT, Gandhinagar </option>
                    <option value="Siddaganga Institute of Technology, Tumkur">Siddaganga Institute of Technology, Tumkur </option>
                    <option value="Mepco Schlenk Engineering College, Sivakasi">Mepco Schlenk Engineering College, Sivakasi </option>
                    <option value="Guru Gobind Singh Indraprastha University, Dwarka">Guru Gobind Singh Indraprastha University, Dwarka </option>
                    <option value="International Institute of Information Technology, Hyderabad">International Institute of Information Technology, Hyderabad </option>
                    <option value="Faculty of Technology and Engineering, Vadodara">Faculty of Technology and Engineering, Vadodara </option>
                    <option value="Army Institute of Technology, Pune">Army Institute of Technology, Pune </option>
                    <option value="PSNA College of Engineering and Technology, Dindigul">PSNA College of Engineering and Technology, Dindigul </option>
                    <option value="Nirma University, Ahmedabad ">Nirma University, Ahmedabad </option>
                    <option value="University College of Engineering, Hyderabad">University College of Engineering, Hyderabad </option>
                    <option value="Sagi Ramakrishnam Raju Engineering College, Bhimavaram">Sagi Ramakrishnam Raju Engineering College, Bhimavaram </option>
                    <option value="Kumaraguru College of Technology, Coimbatore">Kumaraguru College of Technology, Coimbatore </option>
                    <option value="Jaypee University of Information Technology, Solan">Jaypee University of Information Technology, Solan </option>
                    <option value="RMK Engineering College, Kavaraipettai">RMK Engineering College, Kavaraipettai </option>
                    <option value="Punjab Engineering College, Chandigarh">Punjab Engineering College, Chandigarh </option>
                    <option value="PES University, Bengaluru">PES University, Bengaluru </option>
                    <option value="NIT-Manipur">NIT Manipur </option>
                    <option value="Vignan’s Foundation for Science, Technology and Research, Guntur">Vignan’s Foundation for Science, Technology and Research, Guntur </option>
                    <option value="BS Abdur Rahman Institute of Science and Technology, Chennai">BS Abdur Rahman Institute of Science and Technology, Chennai </option>
                    <option value="Chaitanya Bharathi Institute of Technology, Hyderabad">Chaitanya Bharathi Institute of Technology, Hyderabad </option>
                    <option value="Saveetha Engineering College, Sriperumbudur">Saveetha Engineering College, Sriperumbudur </option>
                    <option value="CV Raman College of Engineering, Bhubneshwar">CV Raman College of Engineering, Bhubneshwar </option>
                    <option value="College of Engineering, Trivandrum">College of Engineering, Trivandrum </option>
                    <option value="Maharashtra Institute of Technology, Pune">Maharashtra Institute of Technology, Pune </option>
                    <option value="BMS Institute of Technology and Management, Bengaluru">BMS Institute of Technology and Management, Bengaluru </option>
                    <option value="Sri Sai Ram Engineering College, Chennai">Sri Sai Ram Engineering College, Chennai </option>
                    <option value="St Joseph’s College of Engineering, Chennai">St Joseph’s College of Engineering, Chennai </option>
                    <option value="Andhra University, Visakhapatnam">Andhra University, Visakhapatnam </option>
                    <option value="KS Rangasamy College of Technology, Tiruchengode">KS Rangasamy College of Technology, Tiruchengode </option>
                    <option value="NIT-Meghalaya">NIT Meghalaya </option>
                    <option value="Other">Other</option>
                  </select>
                  
                </div>
              </div>
              <div class="form-row">
                <div class="col-md-4 mb-3 col-sm-3">
                  <label for="PassingYear">Year of Passing</label>
                  <select id="PassingYear" name="PassingYear" class="form-control">
                    <option value="">Choose</option>
                    <option value="2017">2017</option>
                    <option value="2016">2016</option>
                    <option value="2015">2015</option>
                    <option value="2014">2014</option>
                    <option value="2013">2013</option>
                    <option value="2012">2012</option>
                    <option value="2011">2011</option>
                    <option value="2010">2010</option>
                    <option value="2009">2009</option>
                    <option value="2008">2008</option>
                    <option value="2007">2007</option>
                    <option value="2006">2006</option>
                  </select>
            <!--           <div class="invalid-tooltip">
                        Please provide a valid city.
                      </div> -->
                </div>
                <div class="col-md-3 mb-3 col-sm-3">
                  <label for="Percentage">Percentage</label>
                  <input type="text" class="form-control" id="Percentage" name="Percentage" placeholder="Eg: 56" value="" required>
            <!--       <div class="invalid-tooltip">
                    Please provide a valid state.
                  </div> -->
                </div>
                <div class="col-md-2 mb-3 col-sm-3">
                  <label for="CGPAScore">GPA</label>
                  <input type="text" class="form-control" id="CGPAScore" name="CGPAScore" placeholder="" value="" required>
                <!--   <div class="invalid-tooltip">
                    Please provide a valid zip.
                  </div> -->
                </div>
                
                <div class="col-md-3 mb-3 col-sm-3">
                  <label for="NoOfBacklogs">No.Backlogs</label>
                  <input type="text" class="form-control" id="NoOfBacklogs" name="NoOfBacklogs" placeholder="if 0 then -"  value="" required>
               <!--    <div class="invalid-tooltip">
                    Please provide a valid zip.
                  </div> -->
                </div>
                <span  class="form-text text-muted text-justify" style="color:green;">* If No backlogs,0 CGPA or No experience then put  " - "</span>
              </div>
       </div>
</div>

<!-- Work Experience form start here -->
   <div class="card mt-2 ">
          <div class="card-body">
            <h5 class="card-title"><i class="fas fa-briefcase"></i> Work Experience</h5>
            
            <!-- <form> -->
              <div class="form-row">
                <div class="col mr-3">
                     <label for="YearsOfExperience">Years of Experience</label>
                      <input type="text" id="YearsOfExperience" name="YearsOfExperience" class="form-control" placeholder="">
                </div>
                <div class="col">
                          <label>Experience Letter</label><span id="ExperienceLetterErr" style="color: red; font-size: 15px;"> *</span>  <br>
                      <div class="form-check form-check-inline">
                          <input class="form-check-input ml-2" type="radio" name="ExperienceLetter" id="ExperienceLetter" value="YES">
                          <label class="form-check-label ml-1" for="ExperienceYes">YES</label>
                      </div>
                      <div class="form-check form-check-inline">
                          <input class="form-check-input ml-2" type="radio" name="ExperienceLetter" id="ExperienceLetter" value="NO">
                          <label class="form-check-label ml-1" for="ExperienceNo">NO</label>
                      </div>

                </div>
              </div>
              <div class="my-1 ">
                    <div class="form-group">
                    <label for="ExperienceON">Technology / Platform</label>
                    <select class="form-control" id="ExperienceON">
                      <option value="">Select</option>
                      <option value="Android Development">Android Development</option>
                      <option value="BDE">BDE</option>
                      <option value="BI/DWH/Reporting Tools">BI/DWH/Reporting Tools</option>
                      <option value="DBA">DBA</option>
                      <option value="ERP(SAP, Oracle Apps, PeopleSoft)">ERP(SAP, Oracle Apps, PeopleSoft)</option>
                      <option value="Full Stack Developer">Full Stack Developer</option>
                      <option value="iOS Dev">iOS Dev</option>
                      <option value="ITES/BPO/Customer Support">ITES/BPO/Customer Support</option>
                      <option value="Mainframes">Mainframes</option>
                      <option value="S/W Engg. (.Net)">S/W Engg. (.Net)</option>
                      <option value="S/W Engg. (C,C++)">S/W Engg. (C,C++)</option>
                      <option value="S/W Engg. (Java)">S/W Engg. (Java)</option>
                      <option value="S/W Engg. (Perl)">S/W Engg. (Perl)</option>
                      <option value="S/W Engg. (Python)">S/W Engg. (Python)</option>
                      <option value="S/W Engg. (Ruby)">S/W Engg. (Ruby)</option>
                      <option value="System Adminstrator(Linux/Windows)">System Admins.(Linux/Windows)</option>
                      <option value="Testing/QA">Testing/QA</option>
                      <option value="Web Tech(UI/UX Development)">Web Tech(UI/UX Development)</option>
                      <option value="Non-IT">Non-IT</option>
                      <option value="other">other</option>
                    </select>
                  </div>
              </div>
        <!-- </form> -->
          </div>
    </div> 

    <!--start of education loan card     -->
     
    <div class="card mt-2">
            <div class="card-body">
              <h5 class="card-title"><i class="fas fa-suitcase"></i> Education Loan</h5>
              
               <div class="form-row">
                <div class="col-md-6 mb-3 col-sm-6">
                  <label for="LoanAmount"><i class="fas fa-rupee-sign"></i> Loan Amount</label>
                  
                  <select id="LoanAmount" name="LoanAmount" class="form-control">
                    <option value="" >Select</option>
                    <option value="Not Required">Not Required</option>
                    <option value="15Lac - 20Lac">15Lac - 20Lac </option>
                    <option value="20Lac - 25Lac">20Lac - 25Lac</option>
                    <option value="25Lac - 30Lac">25Lac - 30Lac</option>
                    <option value="30Lac - 35Lac">30Lac - 35Lac</option>
                    <option value="35Lac - 40Lac">35Lac - 40Lac</option>          
                    <option value="40Lac - 45Lac">40Lac - 45Lac</option>    
                    <option value="45Lac - 50Lac">45Lac - 50Lac</option>
                    <option value="50Lac - 55Lac">50Lac - 55Lac</option> 
                    <option value="55Lac - 60Lac">55Lac - 60Lac</option>
                    <option value="More than 60Lac">More than 60Lac</option>
                   </select>
                </div>
                <div class="col-md-6 mb-3 col-sm-6">
                      <label for="RequiredBenificial">Required Benificial</label>
                      <select id="RequiredBenificial" class="form-control">
                        <option value="">Choose...</option>
                        <option value="Less Rate of Int">Less Rate of Int</option>
                        <option value="No Co-Applicant Loan">No Co-Applicant Loan</option>
                        <option value="Unsecured Loan">Unsecured Loan</option>
                        <option value="Own Family Fund">Own Family Fund</option>
                        <option value="No Thinked">No Thinked</option>
                      </select>
                  

                  </div>
                  
                  <div class="col-md-6 mb-3 col-sm-6">
                        <label for="AdmitionPlanning"><i class="fa fa-cloud"></i> Planning For</label>
                        
                        <select id="AdmitionPlanning" class="form-control">
                          <option value="">Choose...</option>
                          <option value="Fall 18">Fall 18</option>
                          <option value="Fall 19">Fall 19</option>
                          <option value="Spring 18">Spring 18</option>
                          <option value="Spring 19">Spring 19</option>
                          <option value="Summer 18">Summer 18</option>
                          <option value="Summer 19">Summer 19</option>
                        </select>
                  
                  </div>
                  <div class="col-md-6 mb-3 col-sm-6" >
                      <label for="DreamUniversity"><i class="fa fa-university"></i> Dream University</label>
                      <input type="text" class="form-control" name="DreamUniversity" id="DreamUniversity" placeholder="Dream Uni.">     
                  </div>
              </div>
            </div>          
      </div>  
              <div class="form-group row">
                <div class="col">
                      <small id="emailHelp" class="form-text text-muted text-justify" style="color:green;">By clicking register now, you agree to our Terms and confirm that you have read our <a href="terms.php"  target="_blank">Data Policy</a>. You may receive SMS message and email notifications from Trraks.com and can opt out at any time.</small>
                </div>
              </div>
         <button type="submit" name="SAVE_RECORD" class="btn btn-lg btn-block mt-2" style="background-color: #00193f; color: white"><span id="loader4"><img src="img/form_loading.gif" alt="form_loader" width="25px"></span>SAVE RECORD</button>
</form>   
   
</div>     
<!--end of education loan card-->  

    </div>
    </div>     
</div>


<div class="modal fade bg-one" data-backdrop="static" id="admissionform" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" style="z-index: 9999;">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content bg-color">
              <div class="modal-header">
                  <h4 class="modal-title" id="exampleModalLabel"><b>Admission Form</b></h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
      <div class="modal-body">
        <form>
          <div class="form-group">
            
            <input type="text" class="form-control drop" id="Student_name" value="<?=$_SESSION['Full_Name'];?>" placeholder="Your Full Name">
          </div>
          <div class="form-group">
            
            <input type="email" class="form-control drop" id="Student_email" value="<?=$_SESSION['Email'];?>" placeholder="Enter Your Email">
          </div>
          <div class="form-group">
            
            <input type="tel" class="form-control drop" id="Student_mobile" value="<?=$_SESSION['Mo_No'];?>" placeholder="Enter Your Contact No">
          </div>
           <div class="form-group">
            <select class="custom-select my-1 mr-sm-2 drop"  id="student_city" name="stud_city" >
                    <option value="">Current location</option>
                    <option disabled="disabled" style="background-color:#3E3E3E"><font color="#000000"><i>-Top Metropolitan Cities-</i></font></option>
                    <option>Ahmedabad</option> 
                    <option>Bengaluru/Bangalore</option>
                    <option>Chandigarh</option>
                    <option>Chennai</option>
                    <option>Delhi</option>
                    <option>Gurgaon</option>
                    <option>Hyderabad/Secunderabad</option>
                    <option>Kolkatta</option>
                    <option>Mumbai</option>
                    <option>Noida</option>
                    <option>Pune</option>
                    <option disabled="disabled" style="background-color:#3E3E3E"><font color="#FFFFFF"><i>-Andhra Pradesh-</i></font></option>
                    <option>Anantapur</option>
                    <option>Guntakal</option>
                    <option>Guntur</option>
                    <option>Hyderabad/Secunderabad</option>
                    <option>kakinada</option>
                    <option value="kurnool" <?php if($_SESSION['Current_Location'] == "kurnool") echo 'selected="selected"'; ?>>kurnool</option>
                    <option>Nellore</option>
                    <option>Nizamabad</option>
                    <option>Rajahmundry</option>
                    <option>Tirupati</option>
                    <option>Vijayawada</option>
                    <option>Visakhapatnam</option>
                    <option>Warangal</option>
                    <option>Andra Pradesh-Other</option>
                    <option disabled="disabled" style="background-color:#3E3E3E"><font color="#FFFFFF"><i>-Arunachal Pradesh-</i></font></option>
                    <option>Itanagar</option>
                    <option>Arunachal Pradesh-Other</option>
                    <option disabled="disabled" style="background-color:#3E3E3E"><font color="#FFFFFF"><i>-Assam-</i></font></option>
                    <option>Guwahati</option>
                    <option>Silchar</option>
                    <option>Assam-Other</option>
                    <option disabled="disabled" style="background-color:#3E3E3E"><font color="#FFFFFF"><i>-Bihar-</i></font></option>
                    <option>Bhagalpur</option>
                    <option>Patna</option>
                    <option>Bihar-Other</option>
                    <option disabled="disabled" style="background-color:#3E3E3E"><font color="#FFFFFF"><i>-Chhattisgarh-</i></font></option>
                    <option>Bhillai</option>
                    <option>Bilaspur</option>
                    <option>Raipur</option>
                    <option>Chhattisgarh-Other</option>
                    <option disabled="disabled" style="background-color:#3E3E3E"><font color="#FFFFFF"><i>-Goa-</i></font></option>
                    <option>Panjim/Panaji</option>
                    <option>Vasco Da Gama</option>
                    <option>Goa-Other</option>
                    <option disabled="disabled" style="background-color:#3E3E3E"><font color="#FFFFFF"><i>-Gujarat-</i></font></option>
                    <option>Ahmedabad</option>
                    <option>Anand</option>
                    <option>Ankleshwar</option>
                    <option>Bharuch</option>
                    <option>Bhavnagar</option>
                    <option>Bhuj</option>
                    <option>Gandhinagar</option>
                    <option>Gir</option>
                    <option>Jamnagar</option>
                    <option>Kandla</option>
                    <option>Porbandar</option>
                    <option>Rajkot</option>
                    <option>Surat</option>
                    <option>Vadodara/Baroda</option>
                    <option>Valsad</option>
                    <option>Vapi</option>
                    <option>Gujarat-Other</option>
                    <option disabled="disabled" style="background-color:#3E3E3E"><font color="#FFFFFF"><i>-Haryana-</i></font></option>
                    <option>Ambala</option>
                    <option>Chandigarh</option>
                    <option>Faridabad</option>
                    <option>Gurgaon</option>
                    <option>Hisar</option>
                    <option>Karnal</option>
                    <option>Kurukshetra</option>
                    <option>Panipat</option>
                    <option>Rohtak</option>
                    <option>Haryana-Other</option>
                    <option disabled="disabled" style="background-color:#3E3E3E"><font color="#FFFFFF"><i>-Himachal Pradesh-</i></font></option>
                    <option>Dalhousie</option>
                    <option>Dharmasala</option>
                    <option>Kulu/Manali</option>
                    <option>Shimla</option>
                    <option>Himachal Pradesh-Other</option>
                    <option disabled="disabled" style="background-color:#3E3E3E"><font color="#FFFFFF"><i>-Jammu and Kashmir-</i></font></option>
                    <option>Jammu</option>
                    <option>Srinagar</option>
                    <option>Jammu and Kashmir-Other</option>
                    <option disabled="disabled" style="background-color:#3E3E3E"><font color="#FFFFFF"><i>-Jharkhand-</i></font></option>
                    <option>Bokaro</option>
                    <option>Dhanbad</option>
                    <option>Jamshedpur</option>
                    <option>Ranchi</option>
                    <option>Jharkhand-Other</option>
                    <option disabled="disabled" style="background-color:#3E3E3E"><font color="#FFFFFF"><i>-Karnataka-</i></font></option>
                    <option>Bengaluru/Bangalore</option>
                    <option>Belgaum</option>
                    <option>Bellary</option>
                    <option>Bidar</option>
                    <option>Dharwad</option>
                    <option>Gulbarga</option>
                    <option>Hubli</option>
                    <option>Kolar</option>
                    <option>Mangalore</option>
                    <option>Mysoru/Mysore</option>
                    <option>Karnataka-Other</option>
                    <option disabled="disabled" style="background-color:#3E3E3E"><font color="#FFFFFF"><i>-Kerala-</i></font></option>
                    <option>Calicut</option>
                    <option>Cochin</option>
                    <option>Ernakulam</option>
                    <option>Kannur</option>
                    <option>Kochi</option>
                    <option>Kollam</option>
                    <option>Kottayam</option>
                    <option>Kozhikode</option>
                    <option>Palakkad</option>
                    <option>Palghat</option>
                    <option>Thrissur</option>
                    <option>Trivandrum</option>
                    <option>Kerela-Other</option>
                    <option disabled="disabled" style="background-color:#3E3E3E"><font color="#FFFFFF"><i>-Madhya Pradesh-</i></font></option>
                    <option>Bhopal</option>
                    <option>Gwalior</option>
                    <option>Indore</option>
                    <option>Jabalpur</option>
                    <option>Ujjain</option>
                    <option>Madhya Pradesh-Other</option>
                    <option disabled="disabled" style="background-color:#3E3E3E"><font color="#FFFFFF"><i>-Maharashtra-</i></font></option>
                    <option>Ahmednagar</option>
                    <option>Aurangabad</option>
                    <option>Jalgaon</option>
                    <option>Kolhapur</option>
                    <option>Mumbai</option>
                    <option>Mumbai Suburbs</option>
                    <option>Nagpur</option>
                    <option>Nasik</option>
                    <option>Navi Mumbai</option>
                    <option>Pune</option>
                    <option>Solapur</option>
                    <option>Maharashtra-Other</option>
                    <option disabled="disabled" style="background-color:#3E3E3E"><font color="#FFFFFF"><i>-Manipur-</i></font></option>
                    <option>Imphal</option>
                    <option>Manipur-Other</option>
                    <option disabled="disabled" style="background-color:#3E3E3E"><font color="#FFFFFF"><i>-Meghalaya-</i></font></option>
                    <option>Shillong</option>
                    <option>Meghalaya-Other</option>
                    <option disabled="disabled" style="background-color:#3E3E3E"><font color="#FFFFFF"><i>-Mizoram-</i></font></option>
                    <option>Aizawal</option>
                    <option>Mizoram-Other</option>
                    <option disabled="disabled" style="background-color:#3E3E3E"><font color="#FFFFFF"><i>-Nagaland-</i></font></option>
                    <option>Dimapur</option>
                    <option>Nagaland-Other</option>
                    <option disabled="disabled" style="background-color:#3E3E3E"><font color="#FFFFFF"><i>-Orissa-</i></font></option>
                    <option>Bhubaneshwar</option>
                    <option>Cuttak</option>
                    <option>Paradeep</option>
                    <option>Puri</option>
                    <option>Rourkela</option>
                    <option>Orissa-Other</option>
                    <option disabled="disabled" style="background-color:#3E3E3E"><font color="#FFFFFF"><i>-Punjab-</i></font></option>
                    <option>Amritsar</option>
                    <option>Bathinda</option>
                    <option>Chandigarh</option>
                    <option>Jalandhar</option>
                    <option>Ludhiana</option>
                    <option>Mohali</option>
                    <option>Pathankot</option>
                    <option>Patiala</option>
                    <option>Punjab-Other</option>
                    <option disabled="disabled" style="background-color:#3E3E3E"><font color="#FFFFFF"><i>-Rajasthan-</i></font></option>
                    <option>Ajmer</option>
                    <option>Jaipur</option>
                    <option>Jaisalmer</option>
                    <option>Jodhpur</option>
                    <option>Kota</option>
                    <option>Udaipur</option>
                    <option>Rajasthan-Other</option>
                    <option disabled="disabled" style="background-color:#3E3E3E"><font color="#FFFFFF"><i>-Sikkim-</i></font></option>
                    <option>Gangtok</option>
                    <option>Sikkim-Other</option>
                    <option disabled="disabled" style="background-color:#3E3E3E"><font color="#FFFFFF"><i>-Tamil Nadu-</i></font></option>
                    <option>Chennai</option>
                    <option>Coimbatore</option>
                    <option>Cuddalore</option>
                    <option>Erode</option>
                    <option>Hosur</option>
                    <option>Madurai</option>
                    <option>Nagerkoil</option>
                    <option>Ooty</option>
                    <option>Salem</option>
                    <option>Thanjavur</option>
                    <option>Tirunalveli</option>
                    <option>Trichy</option>
                    <option>Tuticorin</option>
                    <option>Vellore</option>
                    <option>Tamil Nadu-Other</option>
                    <option disabled="disabled" style="background-color:#3E3E3E"><font color="#FFFFFF"><i>-Tripura-</i></font></option>
                    <option>Agartala</option>
                    <option>Tripura-Other</option>
                    <option disabled="disabled" style="background-color:#3E3E3E"><font color="#FFFFFF"><i>-Union Territories-</i></font></option>
                    <option>Chandigarh</option>
                    <option>Dadra & Nagar Haveli-Silvassa</option>
                    <option>Daman & Diu</option>
                    <option>Delhi</option>
                    <option>Pondichery</option>
                    <option disabled="disabled" style="background-color:#3E3E3E"><font color="#FFFFFF"><i>-Uttar Pradesh-</i></font></option>
                    <option>Agra</option>
                    <option>Aligarh</option>
                    <option>Allahabad</option>
                    <option>Bareilly</option>
                    <option>Faizabad</option>
                    <option>Ghaziabad</option>
                    <option>Gorakhpur</option>
                    <option>Kanpur</option>
                    <option>Lucknow</option>
                    <option>Mathura</option>
                    <option>Meerut</option>
                    <option>Moradabad</option>
                    <option>Noida</option>
                    <option>Varanasi/Banaras</option>
                    <option>Uttar Pradesh-Other</option>
                    <option disabled="disabled" style="background-color:#3E3E3E"><font color="#FFFFFF"><i>-Uttaranchal-</i></font></option>
                    <option>Dehradun</option>
                    <option>Roorkee</option>
                    <option>Uttaranchal-Other</option>
                    <option disabled="disabled" style="background-color:#3E3E3E"><font color="#FFFFFF"><i>-West Bengal-</i></font></option>
                    <option>Asansol</option>
                    <option>Durgapur</option>
                    <option>Haldia</option>
                    <option>Kharagpur</option>
                    <option>Kolkatta</option>
                    <option>Siliguri</option>
                    <option>West Bengal - Other</option>
                    <option disabled="disabled" style="background-color:#3E3E3E"><font color="#FFFFFF"><i>-Other-</i></font></option>
                    <option>Other</option>
              
                </select>
           </div>
            <div class="form-group">
                    <select class="custom-select my-1 mr-sm-2 drop" style="margin-bottom:20px" id="expected_country" name="country">
                    <option value="">Desired country</option>
                    <option value="USA" <?php if($_SESSION['country'] == "usa") echo 'selected="selected"'; ?>>USA</option>
                    <option value="Canada" <?php if($_SESSION['country'] == "canada") echo 'selected="selected"'; ?>>Canada</option>
                    <!--
                    <option value="UK">UK</option>
                    <option value="Germany">Germany</option>
                    <option value="Australia">Australia</option>
                    <option value="New Zealand">New Zealand</option>
                       -->
                        </select>

            </div>            
           <div class="form-group"> 
          <select class="custom-select my-1 mr-sm-2 drop" id="expected_stream" name="stream">
            <option value="">Desired Stream</option>
            <option value="MS" <?php if($_SESSION['stream'] == "MS") echo 'selected="selected"'; ?>>MS</option>
            <option value="MBA" <?php if($_SESSION['stream'] == "MBA") echo 'selected="selected"'; ?>>MBA</option>
                </select>
            </div>      

         <div class="form-group"> 
          <select class="custom-select my-1 mr-sm-2 drop" id="desired_program" name="stream">
            <option value="">Desired Program</option>
                   
                    <option value="Aeronotical">Aeronotical</option>
                    <option value="Agriculture">Agriculture</option>
                    <option value="AIE">AIE</option>
                    <option value="Automobile">Automobile</option>
                    <option value="BioChemical">BioChemical</option>
                    <option value="BioInformatics">BioInformatics</option>
                    <option value="BioMedical">BioMedical</option>
                    <option value="BioTechnology">BioTechnology</option>
                    <option value="Chemical">Chemical</option>
                    <option value="Civil">Civil</option>
                    <option value="CSE">CSE</option>
                    <option value="ECE">ECE</option>
                    <option value="EEE">EEE</option>
                    <option value="EIE">EIE</option>
                    <option value="EnergyTechnology">EnergyTechnology</option>
                    <option value="Environmental">Environmental</option>
                    <option value="FireSafety">FireSafety</option>
                    <option value="FoodTechology">FoodTechology</option>
                    <option value="Genetic">Genetic</option>
                    <option value="GeoInformatics">GeoInformatics</option>
                    <option value="GeoScience">GeoScience</option>
                    <option value="IndustrailEngg">IndustrailEngg</option>
                    <option value="IndustrialProduction">IndustrialProduction</option>
                    <option value="InstrumentaionControl">InstrumentaionControl</option>
                    <option value="IT">IT</option>
                    <option value="Leather">Leather</option>
                    <option value="ManMadFiber">ManMadFiber</option>
                    <option value="Manufacturing">Manufacturing</option>
                    <option value="Marine">Marine</option>
                    <option value="MaterialScience">MaterialScience</option>
                    <option value="Mechanical">Mechanical</option>
                    <option value="Mechatronics">Mechatronics</option>
                    <option value="Metallurgical">Metallurgical</option>
                    <option value="Mining">Mining</option>
                    <option value="OceanEngineering">OceanEngineering</option>
                    <option value="ProductionEngineering">ProductionEngineering</option>
                    <option value="ProductionIndustrial">ProductionIndustrial</option>
                    <option value="Textile">Textile</option>
                    <option value="Other">Other</option>    

                </select>
            </div>

               <div class="form-group">
                          <input type="text" class="form-control drop-space" id="univname" placeholder="Enter University Name planning for">
             </div>              
         <div class="form-group form-inline"> 
             <div class="form-group">
          <select class="custom-select my-1 mr-sm-2 drop" id="desired_intake_season" name="stream">
                          <option value="">Desired Intake Season</option>
                          <option value="January">January</option>
                          <option value="February">February</option>                        
                          <option value="March">March</option>
                          <option value="April">April</option>
                          <option value="May">May</option>                        
                          <option value="June">June</option>   
                          <option value="July">July</option>   
                          <option value="August">August</option>   
                          <option value="September">September</option>   
                          <option value="October">October</option>   
                          <option value="November">November</option>   
                          <option value="December">December</option>   
          </select>                
             </div>
               <div class="form-group">
                          <select class="custom-select my-1 mr-sm-2 drop" id="desired_intake_year" name="stream">
                                <option value="">Desired Intake Year</option>
                                  <option value="2018">2018</option>
                                   <option value="2019">2019</option>
                                    <option value="2020">2020</option>

                        </select>
             </div>

        </div>
         <div class="form-group form-inline"> 
             <div class="form-group">
          <select class="custom-select my-1 mr-sm-2 drop" id="EntranceExam" name="stream">
                         <option value="">Entrance Exam Given?</option>
                          <option value="GMAT">GMAT</option>
                          <option value="GRE">GRE</option>     
          </select>                
             </div>
               <div class="form-group">
                    <input type="text" class="form-control drop-space" id="EntranceExamScore" placeholder="Enter Entrance Exam Score">
             </div>

        </div>

         <div class="form-group form-inline"> 
             <div class="form-group">
          <select class="custom-select my-1 mr-sm-2 drop" id="VerbalExam" name="stream">
                         <option value="">Verbal Exam Given?</option>
                          <option value="IELTS">IELTS</option>
                          <option value="PTE">PTE</option>  
                          <option value="TOEFL">TOEFL</option>     
          </select>              
             </div>
               <div class="form-group">
                          <input type="text" class="form-control drop-space" id="VerbalExamScore" placeholder="Enter Verbal Exam Score">
             </div>

        </div>

         <div class="form-group"> 
          <select class="custom-select my-1 mr-sm-2 drop" id="loan_requirement" name="stream">
            <option value="">Looking for Loan?</option>
            <option value="YES">YES</option>
            <option value="NO">NO</option>
          </select>
        </div>


           <div class="form-group">
            
            <input type="text" class="form-control drop-space" id="loan_amount" placeholder="Enter loan amount Eg : 50Lacs if NO then put '-' ">
          </div> 
                   
      
          <div class="modal-footer">
            <button type="button" id="submit" class="btn btn-primary" style="margin-right:185px" > Apply <span id="loader3"><img src="img/form_loading.gif" alt="form_loader" width="25px"></span></button>
          </div>
        </form>

    </div>
  </div>
</div>

</div>
                                          
                                        
<div id="modaloutput">  

<div class="modal fade bottom" id="form_responceupdated" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" style="z-index: 9999;" >
    <div class="modal-dialog modal-frame modal-fluid modal-bottom " role="document">
        <div class="modal-content"  style=" background-color: #5fff426b;">
            <div class="modal-body text-center">
               <span> <h3 style="color:white;">data updated successfully</h3> </span>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade bottom" id="form_responceinserted" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" style="z-index: 9999;" >
    <div class="modal-dialog modal-frame modal-fluid modal-bottom " role="document">
        <div class="modal-content"  style=" background-color: #5fff426b;">
            <div class="modal-body text-center">
               <span> <h3 style="color:white;">data inserted successfully</h3> </span>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<div class="modal fade bottom" id="form_responcefail" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" style="z-index: 9999;">
    <div class="modal-dialog modal-frame modal-fluid modal-bottom " role="document">
        <div class="modal-content" style=" background-color: #ff000096;">
            <div class="modal-body text-center">
               <span> <h3 style="color:white;">Something went wrong try again..!</h3> </span>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
</div>


 <?php
 }

else
{
    echo "<script>alert('Please login with your registered email id');window.location.href='index.php';</script>";

}  
include("footer.php");
  ?>
 
<!-- Result generating script starts here... -->
  <script>

    var nameReg = /^[A-Za-z ]+$/;
    var numberReg =  /^[0-9]/;    
        $(document).ready(function(){
             $("#loader3").hide();
             $("#loader4").hide();
                $("#submit").click(function(){

                var Name = $("#Student_name").val();
                    if(Name == "")
                     {
                         $("#Student_name").css("border", "1px solid red");
                      
                         // setTimeout(function(){ $('#Student_name').css("border", "1px solid"); }, 2000);
                     }
                     else
                     {
                      
                      $("#Student_name").css("border", "1px solid green");
                      }


                 var Email = $("#Student_email").val();
                    if(Email == "")
                     {
                         $("#Student_email").css("border", "1px solid red");
                      
                         // setTimeout(function(){ $('#Student_name').css("border", "1px solid"); }, 2000);
                     }
                     else
                     {
                      
                      $("#Student_email").css("border", "1px solid green");
                      }


                  var Mobile_number = $("#Student_mobile").val();
                    if(Mobile_number == "")
                     {
                         $("#Student_mobile").css("border", "1px solid red");
                      
                         // setTimeout(function(){ $('#Student_mobile').css("border", "1px solid"); }, 2000);
                     }
                     else
                     {
                      
                      $("#Student_mobile").css("border", "1px solid green");
                      }


                   var current_location = $("#student_city").val();
                    if(current_location == "")
                     {
                         $("#student_city").css("border", "1px solid red");
                      
                         // setTimeout(function(){ $('#Student_name').css("border", "1px solid"); }, 2000);
                     }
                     else
                     {
                      
                      $("#student_city").css("border", "1px solid green");
                      }
                    var expected_country = $("#expected_country").val();
                    if(expected_country == "")
                     {
                         $("#expected_country").css("border", "1px solid red");
                      
                         // setTimeout(function(){ $('#Student_name').css("border", "1px solid"); }, 2000);
                     }
                     else
                     {
                      
                         $("#expected_country").css("border", "1px solid green");
                      }


             var expected_stream = $("#expected_stream").val();
                    if(expected_stream == "")
                     {
                         $("#expected_stream").css("border", "1px solid red");
                      
                         // setTimeout(function(){ $('#expected_stream').css("border", "1px solid"); }, 2000);
                     }
                     else
                     {
                      
                      $("#expected_stream").css("border", "1px solid green");
                      }
             var desired_program = $("#desired_program").val();
                    if(desired_program == "")
                     {
                         $("#desired_program").css("border", "1px solid red");
                      
                         // setTimeout(function(){ $('#Student_name').css("border", "1px solid"); }, 2000);
                     }
                     else
                     {
                      
                      $("#desired_program").css("border", "1px solid green");
                      }

             
          var univname = $("#univname").val();
                    if(univname == "" || !nameReg.test(univname))
                     {
                         $("#univname").css("border", "1px solid red");
                      
                         // setTimeout(function(){ $('#desired_intake_season').css("border", "1px solid"); }, 2000);
                     }
                     else
                     {
                      
                      $("#univname").css("border", "1px solid green");
                      }


             var desired_intake_season = $("#desired_intake_season").val();
                    if(desired_intake_season == "")
                     {
                         $("#desired_intake_season").css("border", "1px solid red");
                      
                         // setTimeout(function(){ $('#desired_intake_season').css("border", "1px solid"); }, 2000);
                     }
                     else
                     {
                      
                      $("#desired_intake_season").css("border", "1px solid green");
                      }


            var desired_intake_year = $("#desired_intake_year").val();
                    if(desired_intake_year == "")
                     {
                         $("#desired_intake_year").css("border", "1px solid red");
                      
                         // setTimeout(function(){ $('#desired_intake_year').css("border", "1px solid"); }, 2000);
                     }
                     else
                     {
                      
                      $("#desired_intake_year").css("border", "1px solid green");
                      }

                 var EntranceExam = $("#EntranceExam").val();
                    if(EntranceExam == "")
                     {
                         $("#EntranceExam").css("border", "1px solid red");
                      
                         // setTimeout(function(){ $('#loan_requirement').css("border", "1px solid"); }, 2000);
                     }
                     else
                     {
                      
                      $("#EntranceExam").css("border", "1px solid green");
                      }
                 var EntranceExamScore = $("#EntranceExamScore").val();
                    if(EntranceExamScore == "" || !numberReg.test(EntranceExamScore))
                     {
                         $("#EntranceExamScore").css("border", "1px solid red");
                      
                         // setTimeout(function(){ $('#loan_requirement').css("border", "1px solid"); }, 2000);
                     }
                     else
                     {
                      
                      $("#EntranceExamScore").css("border", "1px solid green");
                      }
                 var VerbalExam = $("#VerbalExam").val();
                    if(VerbalExam == "")
                     {
                         $("#VerbalExam").css("border", "1px solid red");
                      
                         // setTimeout(function(){ $('#loan_requirement').css("border", "1px solid"); }, 2000);
                     }
                     else
                     {
                      
                      $("#VerbalExam").css("border", "1px solid green");
                      }
                 var VerbalExamScore = $("#VerbalExamScore").val();
                    if(VerbalExamScore == "" || !numberReg.test(VerbalExamScore))
                     {
                         $("#VerbalExamScore").css("border", "1px solid red");
                      
                         // setTimeout(function(){ $('#loan_requirement').css("border", "1px solid"); }, 2000);
                     }
                     else
                     {
                      
                      $("#VerbalExamScore").css("border", "1px solid green");
                      }





             var loan_requirement = $("#loan_requirement").val();
                    if(loan_requirement == "")
                     {
                         $("#loan_requirement").css("border", "1px solid red");
                      
                         // setTimeout(function(){ $('#loan_requirement').css("border", "1px solid"); }, 2000);
                     }
                     else
                     {
                      
                      $("#loan_requirement").css("border", "1px solid green");
                      }


            var loan_amount = $("#loan_amount").val();
                    if(loan_amount == "")
                     {
                         $("#loan_amount").css("border", "1px solid red");
                      
                         // setTimeout(function(){ $('#loan_amount').css("border", "1px solid"); }, 2000);
                     }
                     else
                     {
                      
                      $("#loan_amount").css("border", "1px solid green");
                      }





   if (Name !== '' && Email !== '' && Mobile_number !== '' && current_location !== '' && expected_country !== '' && expected_stream !== '' && desired_program !== '' && desired_intake_season !== '' &&  desired_intake_year !== '' && loan_requirement !== '' && loan_amount !== '' && EntranceExam !== '' &&  EntranceExamScore !== '' && VerbalExam !== '' && VerbalExamScore !== '' && univname !== '')
        {

                      var data_string = "NAME=" + Name + "&EMAIL=" + Email + "&Mobile_number=" + Mobile_number + "&current_location=" + current_location + "&expected_country=" + expected_country + "&expected_stream=" + expected_stream + "&desired_program=" + desired_program + "&desired_intake_season=" + desired_intake_season + "&desired_intake_year=" + desired_intake_year + "&loan_requirement=" + loan_requirement + "&loan_amount=" + loan_amount + "&EntranceExam=" + EntranceExam + "&EntranceExamScore=" + EntranceExamScore + "&VerbalExam=" + VerbalExam + "&VerbalExamScore=" + VerbalExamScore + "&univname=" + univname; 
                
                     $.ajax({  
                          type: 'POST',
                          url: 'admission_form_submit.php',
                          data: data_string,
                          beforeSend: function(){
                              // Show image container
                              $("#loader3").show();
                             },
                          success:(function(data) 
                          {
                              // alert(data);
                               $("#loader3").hide();
                             if (data == "inserted") 
                             {
                                alert("Your application for admission submitted successfully.");
                                $('#admissionform').modal('hide');
                                // window.location.href = "universities.php";
                             }else if(data == "fail")
                             {
                                    alert("something went wrong while submitting data.Try again");
                                    // $('#admissionform').modal('hide');
                                    // window.location.href = "universities.php";
                             }else if (data == "exists") 
                             {
                                    alert("Already applied for admission");
                                    $('#admissionform').modal('hide');
                                    // window.location.href = "universities.php";
                             }else
                             {
                                alert("fields are empty");
                                // $('#admissionform').modal('hide');
                             }
                          })
                   });
                      console.log(data_string);
    }

                });

        });




 $(document).ready(function() {
                var Email = '<?= addslashes($_SESSION['Email']); ?>';
             var Country = '<?= addslashes($_SESSION['country']); ?>';
             var ExpStream = '<?= addslashes($_SESSION['stream']); ?>';
             var EntExam = '<?= addslashes($_SESSION['EntExam']); ?>';
             var EntScore = '<?= addslashes($_SESSION['EntExamScr']); ?>';
             var VerbExam = '<?= addslashes($_SESSION['VerExam']); ?>';
             var VerbScore = '<?= addslashes($_SESSION['VerExamScr']); ?>';
             var record = 'COUNTRY=' + Country + '&EMAIL=' + Email + '&ExpStream=' + ExpStream + '&EntExam=' + EntExam + '&EntScore=' + EntScore + '&VerbExam=' + VerbExam + '&VerbScore=' + VerbScore;
                    $.ajax({  
                          type: 'POST',
                          url: 'resultgenerating.php',
                          data: record,
                          success:(function(data) 
                          {
                            // alert(data);
                              var generated_result = JSON.parse(data);
                              // console.log();
                              var length = generated_result.length;
                               // alert(data);
                              
                              if (data == "false") {
                                 var x='  <div class="card"><div class="card-body"><div class="media row"><div class="col-md-12 col-sm-12 text-center" style="color: red;"><p>No record Found</p></div></div></div></div>';
                                   $("#shortlisted-university").append(x);
                            }else
                            {
                             for(var i=0; i < length; i++)
                              {
                                 var x='<div class="card"><div class="card-body" style="background-color: #ffdaa42b"><div class="media row"><div class="col-md-3 col-sm-4"><img class="img-thumbnail mt-3" id="UNIVERSITY_IMG" src="' + generated_result[i].UNIVERSITY_IMG + '" alt="' + generated_result[i].IMG_NAME + '"></div> <div class="col-md-5 col-sm-8"><p class="h3"><a style="color:#18183b" target="_blank">' + generated_result[i].UNIVERSITY_NAME + '</a></p>  <p class="h6 font-weight-light"><a href="' + generated_result[i].WEBSITE + '" target="_blank">' + generated_result[i].WEBSITE + '</a></p><p><small></small></p></div><div class="col-md-4"><div class="row">        <div class="md-12 mt-2">       </div></div></div></div></div>';
                                   $("#shortlisted-university").append(x);

                              }
                               $( "#ModalForm" ).click(function() {
                                  $("#admissionform").show();
                                });
                                   
                            }
                             
                          })
                   });

 }); 
    // <button type="button" id="ModalForm" class="btn btn-primary col-md-12" data-toggle="modal" data-target="#admissionform" data-whatever="@mdo">Proceed with admission</button>        </div>
// result Generating script ends here...

// Form submission script starts here....

 $(document).ready(function() {
$("#ExperienceLetterErr").hide();
  $( "#StudentRecord" ).submit(function( event ) 
  {
    var nameReg = /^[A-Za-z ]+$/;
    var numberReg =  /^[0-9]/;
var numcharReg = /[1-9-\-]/;
    var CurrentDegree = $("#CurrentDegree").val();
    if(CurrentDegree == "")
     {
         $("#CurrentDegree").css("border", "1px solid red");
      
         setTimeout(function(){ $('#CurrentDegree').css("border", "1px solid"); }, 10000);
     }
     else
     {
      
      $("#CurrentDegree").css("border", "1px solid green");
      }


    var CurrentMajor = $("#CurrentMajor").val();
    if(CurrentMajor == "")
     {
         $("#CurrentMajor").css("border", "1px solid red");
      
         setTimeout(function(){ $('#CurrentMajor').css("border", "1px solid"); }, 10000);
     }
     else
     {
      
      $("#CurrentMajor").css("border", "1px solid green");
      }


    var AttendedUniversity = $("#AttendedUniversity").val();
    if(AttendedUniversity == "")
     {
         $("#AttendedUniversity").css("border", "1px solid red");
      
         setTimeout(function(){ $('#AttendedUniversity').css("border", "1px solid"); }, 10000);
     }
     else
     {
      
      $("#AttendedUniversity").css("border", "1px solid green");
      }


    var PassingYear = $("#PassingYear").val();
    if(PassingYear == "")
     {
         $("#PassingYear").css("border", "1px solid red");
      
         setTimeout(function(){ $('#PassingYear').css("border", "1px solid"); }, 10000);
     }
     else
     {
      
      $("#PassingYear").css("border", "1px solid green");
      }

    var Percentage = $("#Percentage").val();
    if(Percentage == "" || Percentage > 100 || !numcharReg.test(Percentage))
     {
         $("#Percentage").css("border", "1px solid red");
      
         setTimeout(function(){ $('#Percentage').css("border", "1px solid"); }, 10000);
     }
     else
     {
      
      $("#Percentage").css("border", "1px solid green");
      }

    var CGPAScore = $("#CGPAScore").val();
    if(CGPAScore == "" || !numcharReg.test(CGPAScore))
     {
         $("#CGPAScore").css("border", "1px solid red");
      
         setTimeout(function(){ $('#CGPAScore').css("border", "1px solid"); }, 10000);
     }
     else
     {
      
        $("#CGPAScore").css("border", "1px solid green");
      }

    var NoOfBacklogs = $("#NoOfBacklogs").val();
    if(NoOfBacklogs == "" || NoOfBacklogs > 10 || !numcharReg.test(NoOfBacklogs))
     {
         $("#NoOfBacklogs").css("border", "1px solid red");
      
         setTimeout(function(){ $('#NoOfBacklogs').css("border", "1px solid"); }, 10000);
     }
     else
     {
      
      $("#NoOfBacklogs").css("border", "1px solid green");
      }

    var YearsOfExperience = $("#YearsOfExperience").val();
    if(YearsOfExperience == ""  || YearsOfExperience > 15 || !numcharReg.test(YearsOfExperience))
     {
         $("#YearsOfExperience").css("border", "1px solid red");
      
         setTimeout(function(){ $('#YearsOfExperience').css("border", "1px solid"); }, 10000);
     }
     else
     {
      
      $("#YearsOfExperience").css("border", "1px solid green");
      }    
    var ExperienceLetter = $("#ExperienceLetter:checked").val();
    if(ExperienceLetter !== "YES" || ExperienceLetter !== "NO")
     {
         $("#ExperienceLetterErr").show();
         setTimeout(function(){ $('#ExperienceLetterErr').hide(); }, 10000);
     }
     else
     {
      $("#ExperienceLetterErr").show();
        $("#ExperienceLetterErr").css("color", "green");
      }

    var ExperienceON = $("#ExperienceON").val();
    if(ExperienceON == "")
     {
         $("#ExperienceON").css("border", "1px solid red");
      
         setTimeout(function(){ $('#ExperienceON').css("border", "1px solid"); }, 10000);
     }
     else
     {
      
      $("#ExperienceON").css("border", "1px solid green");
      }
    var LoanAmount = $("#LoanAmount").val();
    if(LoanAmount == "")
     {
         $("#LoanAmount").css("border", "1px solid red");
      
         setTimeout(function(){ $('#LoanAmount').css("border", "1px solid"); }, 10000);
     }
     else
     {
      
      $("#LoanAmount").css("border", "1px solid green");
      }

    var RequiredBenificial = $("#RequiredBenificial").val();
    if(RequiredBenificial == "")
     {
         $("#RequiredBenificial").css("border", "1px solid red");
      
         setTimeout(function(){ $('#RequiredBenificial').css("border", "1px solid"); }, 10000);
     }
     else
     {
      
      $("#RequiredBenificial").css("border", "1px solid green");
      }

    var AdmitionPlanning = $("#AdmitionPlanning").val();
    if(AdmitionPlanning == "")
     {
         $("#AdmitionPlanning").css("border", "1px solid red");
      
         setTimeout(function(){ $('#AdmitionPlanning').css("border", "1px solid"); }, 10000);
     }
     else
     {
      
      $("#AdmitionPlanning").css("border", "1px solid green");
      }

    var DreamUniversity = $("#DreamUniversity").val();
    if(DreamUniversity == "" || !nameReg.test(DreamUniversity))
     {
         $("#DreamUniversity").css("border", "1px solid red");
      
         setTimeout(function(){ $('#DreamUniversity').css("border", "1px solid"); }, 10000);
     }
     else
     {
      
      $("#DreamUniversity").css("border", "1px solid green");
      }

var Email = '<?= addslashes($_SESSION['Email']); ?>';
    var StudentRecordString = 'CurrentDegree=' + CurrentDegree + '&CurrentMajor=' + CurrentMajor + '&AttendedUniversity=' + AttendedUniversity + '&PassingYear=' + PassingYear + '&Percentage=' + Percentage + '&CGPAScore=' + CGPAScore + '&NoOfBacklogs=' + NoOfBacklogs + '&YearsOfExperience=' + YearsOfExperience + '&ExperienceLetter=' + ExperienceLetter + '&ExperienceON=' + ExperienceON + '&LoanAmount=' + LoanAmount + '&RequiredBenificial=' + RequiredBenificial + '&AdmitionPlanning=' + AdmitionPlanning + '&DreamUniversity=' + DreamUniversity + '&Email=' + Email;


   if (CurrentDegree !== '' && CurrentMajor !== '' && AttendedUniversity !== '' && PassingYear !== '' && Percentage !== '' && CGPAScore !== '' && NoOfBacklogs !== '' && YearsOfExperience !== '' &&  ExperienceON !== '' && LoanAmount !== '' && RequiredBenificial !== '' && AdmitionPlanning !== '' && DreamUniversity !== '')
        {
            // console.log(ExperienceLetter);
                     $.ajax({  
                          type: 'POST',
                          url: 'studentrecord.php',
                          data: StudentRecordString,
                          beforeSend: function(){
                              // Show image container
                              $("#loader4").show();
                             },

                          success:(function(data) 
                          {
                               // alert(data);
                                $("#loader4").hide();
                                if(data === 'updated'){
                                            $('#form_responceupdated').modal('show');
                                }else if(data === 'inserted'){
                                        $('#form_responceinserted').modal('show');
                                }
                                else{
                                    $('#form_responcefail').modal('show');
                                }
                           
                                 
                                    // $("#form_responce").show();
                          })
                   });
        }
  event.preventDefault();
});
 });

// Form submission script ends here...

</script>

<?php
include("header.php");
?>
<div class="container">
  <div class="row">
      <div class="col-md-12">
          <div class="row">
              <div class="col-md-12 p-1 col-sm-12 text-center"><h3 style="font-size: 20px;"><strong>Terms & Policies</strong></h3>
                <hr style=" border-bottom: 4px solid orange;">
              </div>
              <div class="col-md-12 p-1 col-sm-12 text-justify">
                           <p class="mb-5 ">

 We, at <i style="color: green">Trraks Education Platform</i> and our subsidiary organizations around the world, are focused on regarding your online security and perceive your requirement for proper insurance and administration of any by and by identifiable data ("Personal Information") you share with us.
</p>
<p class="mb-5">
</span><h3 style="text-align: center;">"Individual Information"</h3><br><br>
  
implies any data that might be utilized to recognize an individual, including, yet not limited to, a first and last name, a home or other physical address and an email address or other contact data, regardless of whether at work or at home. When all is said in done, you can visit Trraks Education  Platform Web pages without disclosing to us your identity or uncovering any Personal Information about yourself.</p>
<p class="mb-5 ">
 <h3>Treats and Other Tracking Technologies :</h3> <br><br>

Some of our Web pages use "treats" and other following advancements. A "treat" is a little content record that might be utilized, for instance, to gather data about Web webpage movement. A few treats and different advancements may serve to review Personal Information already demonstrated by a Web client. Most programs enable you to control treats, including regardless of whether to acknowledge them and how to evacuate them. <br>

You may set most programs to advise you on the off chance that you get a treat, or you may square treats with your program, however please take note of that in the event that you eradicate or hinder your treats, you should re-enter your unique client ID and secret word to access certain parts of the Web website and a few areas of the webpage would not work. 
<br>

Following advancements may record data, for example, Internet area and host names; Internet convention (IP) addresses; program programming and working framework composes; clickstream examples; and dates and times that our website is gotten to. Our utilization of treats and other following innovations enables us to enhance our Web webpage and your Web involvement. We may likewise investigate data that for patterns and measurements. 
</p>
<p class="mb-5 ">
<h3>Outsider Services : </h3> <br><br>

Outsiders give certain services accessible on <i style="color: green">Trraks Education Platform</i> benefit. <i style="color: green">Trraks Education Platform</i> ' may give data, including Personal Information, that <i style="color: green">Trraks Education Platform</i> gathers on the Web to outsider specialist co-ops to enable us to convey programs, items, data, and services. Specialist co-ops are additionally an essential means by which <i style="color: green">Trraks Education Platform</i> keeps up its Web webpage, Apps and mailing records. <i style="color: green">Trraks Education Platform</i> will find a way to guarantee that these outsider specialist co-ops are committed to ensure Personal Information on <i style="color: green">Trraks Education Platform</i>’s sake. <br>
<i style="color: green">Trraks Education Platform</i> does not expect to exchange Personal Information without your agree to outsiders who are will undoubtedly follow up on <i style="color: green">Trraks Education Platform</i>. sake unless such exchange is lawfully required. Likewise, it is against <i style="color: green">Trraks Education Platform</i>. approach to offer Personal Information gathered online without assent.

<p class="mb-5 "><h3>Your Consent :</h3> <br><br>

By utilizing this Web website, you agree to the terms of our Online Privacy Policy and to <i style="color: green">Trraks Education Platform</i> preparing of Personal Information for the reasons given above and in addition those clarified where <i style="color: green">Trraks Education Platform</i> gathers Personal Information on the Web.

<p class="mb-5 "><h3>Data security :</h3> <br><br>

We take fitting safety efforts to secure against unapproved access to or unapproved adjustment, revelation or pulverization of information. We confine access to your specifically distinguishing data to workers who need to realize that data keeping in mind the end goal to work, create or enhance our services. 

<p class="mb-5 "><h3>Refreshing your data : </h3> <br><br>
We give instruments to refreshing and adjusting your expressly recognizing data for a significant number of our services.

<p class="mb-5 ">Youngsters :</h3> <br> <br>
<i style="color: green">Trraks Education Platform</i> won't contact kids under age 13 about unique offers or for promoting purposes without a parent's consent.</p>

<p class="mb-5"><h3>Data Sharing and Disclosure :</h3> <br><br>

<i style="color: green">Trraks Education Platform</i> does not lease, offer, or offer individual data about you with other individuals (spare with your assent) or non-partnered organizations but to give items or services you've asked for, when we have your consent, or under the accompanying conditions: <br>
We give the data to trusted accomplices who take a shot at sake of or with <i style="color: green">Trraks Education Platform</i> under classification understandings. These organizations may utilize your own data to help <i style="color: green">Trraks Education Platform</i> speak with you about offers from <i style="color: green">Trraks Education Platform</i> and our promoting accomplices. Be that as it may, these organizations don't have any autonomous ideal to share this data. <br>

We react to subpoenas, court orders, or legitimate process, or to set up or practice our lawful rights or protect against lawful cases. <br>

We trust it is important to share data so as to research, avert, or make a move in regards to unlawful exercises, suspected misrepresentation, circumstances including potential dangers to the physical wellbeing of any individual, infringement of <i style="color: green">Trraks Education Platform</i>. terms of utilization, or as generally required by law. <br>

We exchange data about you if <i style="color: green">Trraks Education Platform</i> is obtained by or converged with another organization. In this occasion, <i style="color: green">Trraks Education Platform</i> will advise you before data about you is exchanged and winds up plainly subject to an alternate security arrangement. <br>

<i style="color: green">Trraks Education Platform</i> showcases focused on notices in view of individual data. Publicists (counting advertisement serving organizations) may expect that individuals who communicate with, view, or tap on focused promotions meet the focusing on criteria - for instance, ladies ages 18-24 from a specific geographic territory. <br>

<i style="color: green">Trraks Education Platform</i> does not give any individual data to the sponsor when you cooperate with or see a focused on advertisement. Nonetheless, by collaborating with or seeing a promotion you are consenting to the likelihood that the sponsor will make the presumption that you meet the focusing on criteria used to show the advertisement. <br>

<i style="color: green">Trraks Education Platform</i> promoters incorporate money related specialist organizations, (for example, banks, protection operators, stock dealers and home loan moneylenders) and non-monetary organizations, (for example, stores, aircrafts, and programming organizations). <br>

<i style="color: green">Trraks Education Platform</i> works with sellers, accomplices, publicists, and other specialist organizations in various enterprises and classifications of business. For more data in regards to suppliers of items or services that you've asked for please perused our definite reference joins.
</p>
<p class="mb-5"><h3>Secrecy and Security :</h3> <br><br>

We restrict access to individual data about you to workers who we accept sensibly need to come into contact with that data to give items or services to you or keeping in mind the end goal to carry out their occupations. <br>

We have physical, electronic, and procedural shields that conform to the laws pervasive in India to secure individual data about you. We look to guarantee consistence with the prerequisites of the Information Technology Act, 2000 and Rules made there under to guarantee the assurance and conservation of your security. </p>

<p class="mb-5"><h3>Changes to this Privacy Policy :</h3> <br><br>

<i style="color: green">Trraks Education Platform</i> claims all authority to refresh, change or alter this approach whenever. The approach might come to impact from the date of such refresh, change or alteration. </p>

<p class="mb-5"><h3>Disclaimer :</h3><br><br>

<i style="color: green">Trraks Education Platform</i> does not store or keep Visa information in an area that is available by means of the Internet. <i style="color: green">Trraks Education Platform</i> uses the greatest care as is conceivable to guarantee that all or any information/data in regard of electronic exchange of cash does not fall in the wrong hands.<br> 
<i style="color: green">Trraks Education Platform</i> might not be at risk for any misfortune or harm maintained by reason of any revelation (accidental or something else) of any data concerning the client's record and/or data identifying with or in regards to online exchanges utilizing charge cards/platinum cards and/or their confirmation procedure and particulars nor for any blunder, exclusion or incorrectness as for any data so revealed and utilized regardless of whether in compatibility of a lawful procedure or something else.
</p>
               </div>
          </div>
      </div>
  </div>
</div>

<!-- end of jumbotron -->


<!-- end of evaluation form section -->
       
<!--Apply load C2A section-->

<!--       End Of About Section-->


<!-- Footer coad is here -->

<!--Footer-->
<?php
include("footer.php");
?>
